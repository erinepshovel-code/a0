from a0.core.heartbeat.engine import HeartbeatEngine
from a0.core.psi.engine import PsiEngine
from a0.core.omega.engine import OmegaEngine


class Orchestrator:
    def __init__(self):
        self.heartbeat = HeartbeatEngine()
        self.psi = PsiEngine()
        self.omega = OmegaEngine()

    def cycle(self):
        return [self.heartbeat.tick(), self.psi.tick(), self.omega.tick()]
