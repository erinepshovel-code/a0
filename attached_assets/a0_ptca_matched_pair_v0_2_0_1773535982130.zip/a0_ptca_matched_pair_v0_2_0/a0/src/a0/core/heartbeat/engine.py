class HeartbeatEngine:
    """World-facing cadence and event intake."""

    def tick(self) -> dict:
        return {"core": "heartbeat", "status": "ok"}
