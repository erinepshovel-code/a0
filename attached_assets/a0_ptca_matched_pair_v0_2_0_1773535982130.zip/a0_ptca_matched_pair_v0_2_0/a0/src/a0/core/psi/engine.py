class PsiEngine:
    """Interpretation and synthesis core."""

    def tick(self) -> dict:
        return {"core": "psi", "status": "ok"}
