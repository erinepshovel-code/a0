# Runtime

## Responsibility
Coordinate the three cores, maintain cadence, and expose bounded action surfaces.

## Default cycles
- External heartbeat cycle: 8 hours
- Internal system build cycle: 5 minutes
- Self-deploy check cycle: 5 minutes
