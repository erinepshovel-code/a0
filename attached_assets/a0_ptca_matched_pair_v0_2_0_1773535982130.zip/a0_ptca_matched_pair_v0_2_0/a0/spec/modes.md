# Modes

- runtime normal
- bounded sudo
- unbound sudo release
