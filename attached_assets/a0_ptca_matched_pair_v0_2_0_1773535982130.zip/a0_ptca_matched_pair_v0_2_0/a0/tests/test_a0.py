import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1] / 'src'))

from a0.runtime.orchestrator import Orchestrator


def test_cycle_has_three_cores():
    out = Orchestrator().cycle()
    assert len(out) == 3
    assert {x['core'] for x in out} == {'heartbeat', 'psi', 'omega'}
