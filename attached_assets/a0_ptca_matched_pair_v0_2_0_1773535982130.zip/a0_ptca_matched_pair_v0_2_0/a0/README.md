# A0

A0 is the instantiated runtime embodiment of PTCA.

## Core split
- Heartbeat: world-facing cadence, scheduling, sensing, deployment rhythm
- Psi: interpretation, synthesis, discernment, council coordination
- Omega: commitment, integration, release, terminal authority layer
