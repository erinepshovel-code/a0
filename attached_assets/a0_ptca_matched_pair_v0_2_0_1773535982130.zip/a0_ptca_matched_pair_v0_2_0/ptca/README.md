# PTCA

PTCA is the canon and reference-contract repo for the hyperdimensional core architecture embodied by A0.
