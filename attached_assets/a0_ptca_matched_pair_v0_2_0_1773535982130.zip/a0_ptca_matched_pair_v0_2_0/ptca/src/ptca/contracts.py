from dataclasses import dataclass


@dataclass(frozen=True)
class CoreContract:
    name: str
    role: str


CORE_CONTRACTS = (
    CoreContract('heartbeat', 'world-facing cadence'),
    CoreContract('psi', 'interpretation and synthesis'),
    CoreContract('omega', 'commitment and release'),
)
