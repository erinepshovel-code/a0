import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1] / 'src'))

from ptca.contracts import CORE_CONTRACTS


def test_three_core_contracts():
    assert len(CORE_CONTRACTS) == 3
    assert [c.name for c in CORE_CONTRACTS] == ['heartbeat', 'psi', 'omega']
