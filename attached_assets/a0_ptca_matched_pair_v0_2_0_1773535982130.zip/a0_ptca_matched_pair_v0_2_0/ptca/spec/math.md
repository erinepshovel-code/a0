# Math

This starter preserves placeholders for the hyperdimensional exchange math rather than pretending the final formalism is frozen.
