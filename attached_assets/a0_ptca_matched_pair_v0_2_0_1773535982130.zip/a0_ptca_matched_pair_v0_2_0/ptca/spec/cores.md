# Cores

- Heartbeat: external cadence and world contact
- Psi: interpretation and synthesis
- Omega: commitment and irreversible release
