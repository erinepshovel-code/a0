# Invariants

- three primary cores
- explicit exchange contracts
- no silent privilege escalation
- bounded runtime mode separation
