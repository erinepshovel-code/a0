# Exchanges

Core-to-core exchange should support constant and phase-mapped operations.
Exact tensor exchange math remains subject to frozen PCNA adjacency contracts.
