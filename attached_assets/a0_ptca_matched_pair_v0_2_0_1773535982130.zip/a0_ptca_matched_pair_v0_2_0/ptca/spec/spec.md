# PTCA Spec

PTCA defines the core exchange architecture and invariant contracts for A0-class runtimes.
