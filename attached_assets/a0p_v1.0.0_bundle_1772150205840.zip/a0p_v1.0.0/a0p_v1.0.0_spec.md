# a0p v1.0.0 — PTCA/PCNA + EDCMBONE + Grok/Gemini Dual-Brain (Frozen Spec)

**Attribution:** GPT generated; context, prompt Erin Spencer  
**Date:** 2026-02-26  
**Anchors:** Canon invariants + sentinels fileciteturn0file0 ; Interdependent Way ethos fileciteturn0file1

## 0) Root invariant
Every artifact/event/output MUST include `hmmm` (fail-closed). fileciteturn0file0

## 1) Purpose
a0p orchestrates two external model brains (Grok + Gemini) in parallel, evaluates structural alignment via EDCMBONE, synthesizes via PTCA/PCNA constraints, and requires explicit user approval for any external action.

## 2) Determinism (v1 hard freeze)
No randomness; all parameters, thresholds, topology, merge rules, gate grammar, and hash-chain are fixed and versioned.

## 3) Interfaces

### 3.1 A0Request (contract)
- task_id: string
- mode: analyze|route|act
- input: { text: string, files: [...], metadata: object }
- tools_allowed: object
- hmmm: object (required)

### 3.2 A0Response (contract)
- task_id
- result: { text, artifacts[] }
- logs: { events[] }
- hmmm (required)

## 4) Dual-brain parallel inference
Given U:
- R₁ = Grok(U)
- R₂ = Gemini(U)

No cross-feeding.

## 5) EDCMBONE (operator discernment)
Operator vector O(X) ∈ ℝ⁵ over classes [P,K,Q,T,S]. fileciteturn0file0

### 5.1 Normalization (frozen)
L1 with epsilon 1e-9:
O_norm = v / (Σ|vᵢ| + 1e-9)

### 5.2 Divergence measures (frozen, L2)
Δ_bone = ||O(R₁)-O(R₂)||
Δ_alignᵢ = ||O(U)-O(Rᵢ)||

Thresholds (frozen):
- merge if Δ_bone ≤ 0.18
- soft-fork if 0.18 < Δ_bone ≤ 0.30
- fork if Δ_bone > 0.30
- flag alignment risk if any Δ_alignᵢ > 0.25

(Full parameter JSON: `edcmbone_params_v1.json`)

## 6) PCNA topology (frozen)
n = 53 nodes on a circular index set. fileciteturn0file0

Adjacency is symmetric circular distances D = {1,2,3,4,5,6,7,14}.
Adjacency list is precomputed and stored as `pcna_adjacency_v1.json`.

Node init (frozen):
xᵢ(0)=0, bᵢ=0.

## 7) PTCA flow (frozen numerics)
Transport over θ with periodic boundary. fileciteturn0file0

Discretization: Explicit Euler  
Δt = 0.01, Δθ = 2π/53, steps_per_eval = 10

Parameters (frozen):
α=0.6, β=0.4, γ=0.2  
b(A)=A  
k(A)=0.1+0.2A  
R(U)=0.3U  
coherence(U)=1-Var(U)  
overload(U)=max(0,||U||₂-1)  
Clamp all state values to [-2,2]

Flow instability threshold (frozen): D_flow > 0.30.

(Full parameter JSON: `ptca_params_v1.json`)

## 8) Response synthesis (frozen merge semantics)
Merge unit: paragraph blocks.

If merge:
1) Prefer higher Stabilityᵢ = 1 − (Δ_alignᵢ / (1+||O(U)||)).  
2) De-duplicate paragraphs if cosine similarity ≥ 0.95.  
3) If factual conflict detected, preserve both claims explicitly (no rewriting).

## 9) Approval gate (frozen)
Any external write/spend/permissions/outreach requires a gate:
- output: GATE_ID, ACTION_SET, RISK_PROFILE
- user must reply exactly: `APPROVE <SHA256_GATE_ID>`

Details in `gate_spec_v1.md`. fileciteturn0file0

## 10) Event log + hash chain (frozen)
Append-only `events.jsonl` with SHA-256 hash chain. fileciteturn0file0
- H0 = SHA256("a0p-genesis")
- Hn = SHA256(Hn-1 + canonical_event_json)

Canonical JSON:
- sorted keys, no whitespace, floats 6 decimals.

## 11) Sentinels (frozen roster)
S1..S9 enforced as in canon. fileciteturn0file0

## 12) Resource policy (frozen)
- Call both models, max 4096 tokens each.
- No retries.
- One fails → proceed with the other.
- Both fail → halt.

hmmm
```json
{
  "hmmm": {
    "items": [
      {
        "id": "hmmm-a0p-v1-001",
        "status": "resolved",
        "note": "v1.0.0 deterministic freeze applied across thresholds, topology, PTCA numerics, merge, gate grammar, and hash chain.",
        "owner": "S1",
        "created_at": "2026-02-26T00:00:00Z"
      },
      {
        "id": "hmmm-a0p-v1-002",
        "status": "open",
        "note": "Freeze full operator inventory mapping (tokens/affixes/punct) into P/K/Q/T/S (edcmbone_operator_inventory_v1.json).",
        "owner": "S3",
        "created_at": "2026-02-26T00:00:00Z"
      }
    ]
  }
}
```

