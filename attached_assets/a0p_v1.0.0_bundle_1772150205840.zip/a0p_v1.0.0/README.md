# a0p v1.0.0 — Frozen File Bundle

This folder contains the frozen spec and parameter files for:
- a0p orchestration (dual-brain Grok+Gemini)
- EDCMBONE operator discernment
- PCNA topology (n=53)
- PTCA numerical dynamics
- Approval gate grammar + hashing
- Canon anchor docs copied in

## Contents
- a0p_v1.0.0_spec.md
- gate_spec_v1.md
- edcmbone_params_v1.json
- edcmbone_operator_inventory_v1.json (OPEN SLOT)
- pcna_adjacency_v1.json
- ptca_params_v1.json
- canon_definitions_invariants.md (copied)
- Interdependent Way.txt (copied)
- MANIFEST_SHA256.txt

hmmm
```json
{
  "hmmm": {
    "items": [
      {
        "id": "hmmm-a0p-bundle-001",
        "status": "resolved",
        "note": "Bundle assembled for download with spec + params + adjacency + gate + manifest.",
        "owner": "S1",
        "created_at": "2026-02-26T00:00:00Z"
      }
    ]
  }
}
```

