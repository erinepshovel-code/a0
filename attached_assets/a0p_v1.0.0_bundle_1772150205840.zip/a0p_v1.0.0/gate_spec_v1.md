# a0p v1.0.0 — Approval Gate Spec (Frozen)

Only accepted approval string (case-sensitive):

`APPROVE <SHA256_GATE_ID>`

## Gate ID

`GATE_ID = SHA256(canonical_json(action_set))`

### Canonical JSON rules (frozen)
- Sorted keys
- No whitespace
- Floats serialized with 6 decimal places

## Expiry (frozen)
- 24 hours after issuance, OR
- invalidated immediately upon any new event logged in the same task_id stream.

hmmm
```json
{
  "hmmm": {
    "items": [
      {
        "id": "hmmm-a0p-gate-001",
        "status": "resolved",
        "note": "Gate grammar + gate_id hashing + expiry frozen for v1.",
        "owner": "S4",
        "created_at": "2026-02-26T00:00:00Z"
      }
    ]
  }
}
```

