# Canon — Definitions, Invariants, and Open Slots
**Status:** working canon aggregator (single file)  
**Updated:** 2026-02-24 23:33:03Z  
**Attribution:** GPT generated; context, prompt Erin Spencer

---

## 0) Global Hard Invariant: `hmmm`
Every action/event/artifact/response MUST include `hmmm`.

Minimum schema (allowed empty list):
```json
"hmmm": {
  "items": [
    {
      "id": "hmmm-###",
      "status": "open|blocked|needs-evidence|deferred|resolved",
      "note": "short statement",
      "owner": "S1|S4|S5|S6|S8|S9|R0",
      "created_at": "ISO-8601"
    }
  ]
}
```

**Fail-closed:** absence forbidden.  
**Enforced by:** S1 (event write) and S9 (outbound output).

hmmm

---

## 1) Systems and Their Roles (Definitions)

### 1.1 EDCM — Energy–Dissonance Circuit Model
**Definition:** a diagnostic framework that treats dissonance as **unresolved constraint mismatch** (not feeling).  
**Models:** behavior under constraint (not beliefs/intentions/morality/consciousness/internal state).  
**Core circuit metaphor:** energy accumulates when constraints can’t be simultaneously satisfied; the energy must flow, store, or fail.

**Dual-layer framing (as established):**
- **Operator layer (“bones-only”)**: closed-class tokens + bound morphemes (+ selected punct/connectors) → operator vector **O ∈ ℝ⁵**.
- **Behavioral layer (9-metric form)**: round-native behavioral proxies **B ∈ ℝ⁹**.
- **Bridge layer**: observational correlations/divergence; never modifies O or B.

hmmm

### 1.2 PCNA — Prime Circular Neural Architecture
**Definition:** static graph-based architecture on a circular prime index set.  
**Role:** defines topology (nodes/edges/routing constraints).  
**Node update:** xᵢ(t+1) = σ( Σⱼ Wᵢⱼ xⱼ(t) + bᵢ )  
**Edges E defined by:** prime gaps, modular adjacency, heptagram projection rules.

hmmm

### 1.3 PCTA — Prime Circular Tensor Architecture
**Definition:** dynamic transport (flow) on a circular prime-indexed lattice/topology.  
**Role:** defines flow/transport over PCNA’s topology (consumes state; does not change measurement outputs).  
**Base transport (canonical form):**
∂U/∂t = -b(A)∂U/∂θ + k(A)∂²U/∂θ² + S(θ,t) - R(U)  
Gate dynamics:
∂A/∂t = α·coherence(U) - β·overload(U) - γA

hmmm

### 1.4 PCNA-CA — Cloud Agent Runtime (Event + Heartbeat)
**Definition:** cloud-hosted agent runtime that routes tasks through routers/cells, produces auditable artifacts, and enforces gating/safety/provenance via sentinels.  
**Mode:** event-driven primary + heartbeat every 8 hours (maintenance-only).  
**No silent external actions. No hidden memory. No unlogged behavior.**

hmmm

### 1.5 A0 — Agent Zero (Minimal Wrapper)
**Definition:** root orchestration wrapper that accepts an A0Request, routes to tools/models deterministically when possible, logs events append-only, and emits A0Response.  
**Core constraint:** contract stability anchor; tools/adapters may swap without breaking contract.  
**Default stance:** CLI-first; connector-ready; service-ready.

hmmm

---

## 2) Canon Objects (Schemas by Concept)

### 2.1 Transcript Canon (“He said / She said / They said”)
**Actor**
```json
{"actor_id":"string","display_name":null,"role":null}
```

**Utterance** (lossless span)
```json
{"utterance_id":"string","actor_id":"string","raw_text":"...","t_start":null,"t_end":null,"source_ref":null}
```

**Turn** (atomic structural unit)
```json
{"turn_id":"string","actor_id":"string","utterance_ids":["..."],"raw_text":"...","tokens_surface":["..."],"t_start":null,"t_end":null}
```

**Round**
- 2 actors: [A_turn, B_turn(s)] until A returns.
- 3+ actors: initiator-return closure; ends immediately before next initiator turn; if transcript ends early → status="open".

hmmm

---

## 3) Frozen Invariants (Hard Rules)

### 3.1 Losslessness
- Preserve raw text at utterance level.
- Do not reassign speaker unless upstream attribution exists; unknown speaker → actor_id="UNK".
- UNK never merges with neighbors.

hmmm

### 3.2 Determinism
- Same input → same turns/rounds (given same canon rules).
- Turn boundaries:
  - new turn when actor changes
  - explicit boundary markers force new turn
  - quoted speech inside a turn does NOT change actor_id

hmmm

### 3.3 SYS / TOOL Handling
- system/tool/instruction messages:
  - actor_id = "SYS" or "TOOL:<name>"
  - included in ordering
  - excluded from rounds by default
  - excluded from Operator-EDCM by default (Behavioral excludes SYS by default)

hmmm

### 3.4 Operator-EDCM (“Bones-only”) Freezes
- Lowercase before matching.
- Contractions split into morphemes:
  - n’t → P
  - ’ll → T
  - ’d → T
- Hyphenated compound words emit exactly **one** K token per compound word; internal free bones processed normally.
- En dash “–” counts as K (range/connection).
- Em dash “—” is boundary marker only; emits 0 operator tokens.
- “?” emits exactly one Q token.
- “/” ignored for operator counting in v1 (preserve losslessly).
- Collision family priority (frozen): **P > K > Q > T > S**
- Affix extraction: longest-match-first; emit all matched prefixes/suffixes; derivational suffixes included under S (Option B).

hmmm

### 3.5 Aggregation Alignment (Operator → Round)
- Compute Operator per **Turn**.
- Aggregate to Round by **summing bone counts across turns** then renormalize.
- Do NOT mean-average turn vectors.

hmmm

### 3.6 Behavioral Layer Placement
- Behavioral-EDCM computed **round-native** on CLOSED rounds by default.
- Default windowing (frozen):
  - Operator window: W_turn(k=8)
  - Behavioral window: W_round(m=4)

hmmm

### 3.7 Bridge Layer (Read-only)
- Correlations Corr(O_f, B_metric) over rolling windows.
- Divergence flags: operator shift without behavioral shift and vice versa.
- Bridge does not modify Operator or Behavioral.

hmmm

### 3.8 PCNA/PCTA Routing Constraints
- Routing consumes state vectors; does not modify EDCM outputs.
- Optional routing output: distribution π(W) over probes/actions + stability logs.

hmmm

---

## 4) PCNA-CA Runtime Invariants (Cloud Agent)

### 4.1 Execution Model
**Event-driven loop (primary):**
- inbound HTTP tasks / webhooks
- queue messages
- file uploads
- approval replies

**Per-event requirements:**
- sentinel preflight + postflight
- deterministic router_path in provenance
- fail-closed on missing invariants

hmmm

### 4.2 Heartbeat (every 8 hours)
Heartbeat MUST:
- emit HEARTBEAT_LOG every run
- detect heartbeat gaps; emit HEARTBEAT_GAP on next run
- never initiate new external actions
- never expand goals
- never modify safety policy

Heartbeat MAY:
- verify hash-chain integrity
- refresh snapshots
- recompute trend summaries (EDCM + stability)
- queue hygiene (re-enqueue safe stalled jobs)
- propose/apply bounded micro-optimizations (bandits) with rollback

hmmm

### 4.3 Autonomy + Approval Gates
**Undoable (auto):**
- parsing, metrics, summaries
- drafting artifacts without external write
- bounded internal tuning with rollback
- cache reuse/snapshotting

**Approval-required (gate):**
- any external write (publish/post/send/push/create PR)
- enabling paid services/spending
- permissions/secrets changes
- outreach to humans
- monetization execution

Approval protocol example: `APPROVE <gate_id>`.

hmmm

### 4.4 Storage Model (Canonical)
Source of truth: append-only `events.jsonl` with hash chain.

Per thread:
- events.jsonl
- latest_snapshot.json (S7)
- parse_state.json (optional)
- metrics_state.json (EDCM)
- artifacts/ (md/json/pdf)
- provenance.json (hash chain, versions)

No hidden memory. Persisted changes are events.

hmmm

### 4.5 Nine Child Sentinels (Canon)
- S1 Provenance & Audit
- S2 Parser Integrity
- S3 Constraint / EDCM
- S4 Safety & Approval
- S5 Drift / Hallucination
- S6 Coherence / Conflict
- S7 Compression / Recall
- S8 Budget / Resource
- S9 Output Policy

hmmm

---

## 5) A0 Minimal Contract (Wrapper Invariants)

### 5.1 Contract Objects
**A0Request**
- task_id
- input: {text, files, metadata}
- tools_allowed
- mode: analyze|route|act
- hmm (list)

**A0Response**
- task_id
- result: {text, artifacts}
- logs: {events}
- hmm (list)

hmmm

### 5.2 Logging
- Append-only JSONL per task_id
- Each event includes timestamp
- No silent external actions

hmmm

---

## 6) EDCM Metrics (Behavioral Proxies)
This section is a *placeholder summary* of currently implemented proxies (DA, CE, GL, RM, RPI) and their constraints:

- Observable outputs only
- Falsifiable proxies
- Degradation allowed; polarity must not invert
- If a metric can’t be computed without “story”, disable it

**[TBD SLOT]** Canonical marker inventories (GL/RM) and any expansions.

hmmm

---

# 7) Open Slots (Explicit Unknowns / Not Yet Established)

## 7.1 Operator Layer Open Slots
- **[TBD]** Full bone inventory (words/affixes/punct) versioning policy beyond v1 file names
- **[TBD]** Slash “/” mapping decision (ignored vs K)
- **[TBD]** SYS contribution to operator baseline (currently excluded)

hmmm

## 7.2 Behavioral Layer Open Slots
- **[TBD]** Frozen behavioral marker lists (v1) beyond high-level categories
- **[TBD]** Fully structural replacements for semantic/embedding-based components
- **[TBD]** Canonical contradiction detection method for C (Constraint Strain)

hmmm

## 7.3 Bridge Layer Open Slots
- **[TBD]** Divergence thresholds and alerting policy (default 0.20 referenced elsewhere)
- **[TBD]** Correlation window definitions (turn-count vs bone-count vs time)

hmmm

## 7.4 PCNA / PCTA Open Slots
- **[TBD]** Prime density vs compute tradeoff policy
- **[TBD]** Exact adjacency tables / heptagram projection parameters (k set, layer rules)
- **[TBD]** Freeze vs thrash boundary tuning (λ, α, β, γ; CFL policy)

hmmm

## 7.5 PCNA-CA Runtime Open Slots
- **[TBD]** Initial reward weights: stability vs cost vs speed (S8-owned)
- **[TBD]** Demo vertical selection: legal transcripts vs research audits vs policy analysis vs dev tooling (R0-owned)
- **[TBD]** Monetization SKU: transcript integrity pack vs EDCM stability report vs provenance hash-chain package (S9-owned)

hmmm

---

## 8) Working `hmmm` Register (Seed Items)
```json
{
  "hmmm": {
    "items": [
      {
        "id": "hmmm-canon-001",
        "status": "open",
        "note": "Pick initial reward weights: stability vs cost vs speed.",
        "owner": "S8",
        "created_at": "ISO-8601"
      },
      {
        "id": "hmmm-canon-002",
        "status": "open",
        "note": "Select first demo vertical: legal transcripts, research audits, policy analysis, or dev tooling.",
        "owner": "R0",
        "created_at": "ISO-8601"
      },
      {
        "id": "hmmm-ship-001",
        "status": "open",
        "note": "Decide if bandit optimizes only routing weights or also budget caps (still bounded).",
        "owner": "S8",
        "created_at": "ISO-8601"
      }
    ]
  }
}
```

hmmm
